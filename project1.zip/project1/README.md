# Project 1

Run portfolio.jl with julia to get information about the Apple and Amazon stock information as well as information about portfolios derived from the stocks

Similarley can run the portfolio.py and will recieve same information

